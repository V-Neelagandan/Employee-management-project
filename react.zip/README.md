// rafce is shortcut
  // this Fragment <></>
  // npm i react-router-dom install routes and route
  // every route path='' element='' should be add
  // Create Components folder inside Src
  // in the all the components files created -- create rafce 
  // And Create Main folder in Components folder
  // in Main folder create Header,Hero and Sidebar Jsx files

  This what Routes and Route Mapping the Paths

      <Routes>

        <Route path='' element={<Home/>}/>
        <Route path='AddEmployee' element={<AddEmployee/>}/>
        <Route path='EditEmployee' element={<EditEmployee/>}/>
        <Route path='ViewEmployee' element={<ViewEmployee/>}/>
        <Route path='ViewEmployeeByID' element={<ViewEmployeeByID/>}/>

      </Routes>