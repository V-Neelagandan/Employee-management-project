import React, { createContext } from "react";

// CREATING A CONTEXT TO PROVIDE THE URL TO ALL THE COMPONENTS
const ApiContext = createContext();

export default ApiContext;


