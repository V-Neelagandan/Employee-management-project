import React from 'react'
import Header from './Main/Header'
const ViewEmployeeByID = () => {
  return (
    <>
    <Header/>
    </>
  )
}

export default ViewEmployeeByID
