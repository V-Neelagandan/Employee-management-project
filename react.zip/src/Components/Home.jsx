import React from 'react'
import Header from './Main/Header'
import './Css/H1.css'



const Home = () => {
  return (
    <>
    <Header/>

    <div className='h1'>
           <h1 className='tit'>EMPLOYEE MANAGEMENT <br/></h1>  
            <h3>PORTAL</h3>
    </div>

    </>
  )
}

export default Home

